<?php
declare(strict_types=1);
ini_set('display_errors','0');
// Production runtime is deliberately outside the public document root.
$ihRuntime=getenv('IH_RUNTIME_DIR')?:dirname(__DIR__).'/../iholytech-private-runtime';
$ihRuntime=realpath($ihRuntime);$ihPublic=realpath($_SERVER['DOCUMENT_ROOT']??dirname(__DIR__));
if(!$ihRuntime||!$ihPublic||str_starts_with(strtolower(str_replace('\\','/',$ihRuntime)).'/',strtolower(str_replace('\\','/',$ihPublic)).'/')||!is_file($ihRuntime.'/server/ContactService.php')){http_response_code(503);header('Content-Type: application/json');header('Cache-Control: no-store, private');echo json_encode(['ok'=>false,'message'=>'Service configuration is unavailable.']);exit;}
if(getenv('IH_APP_ENV')===false)putenv('IH_APP_ENV=production');
require $ihRuntime.'/server/ContactService.php';
use IHolyTech\Contact\Fault;
header_remove('X-Powered-By');header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");header('Cross-Origin-Resource-Policy: same-origin');
function contactRespond(int $status,array $data):never{http_response_code($status);echo json_encode($data,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);exit;}
try{
 $method=$_SERVER['REQUEST_METHOD']??'';if(!in_array($method,['GET','POST'],true)){header('Allow: GET, POST');throw new Fault(405,'This request method is not supported.');}
 $c=IHolyTech\Contact\config();if(!$c['enabled']){if($method==='GET')contactRespond(200,['enabled'=>false,'message'=>'Preview mode. Enquiry delivery is not configured; nothing will be sent.']);throw new Fault(503,'Enquiry delivery is disabled. Nothing was sent.');}
 $origin=$_SERVER['HTTP_ORIGIN']??'';if($method==='POST'&&(!hash_equals($c['ORIGIN'],$origin)||!in_array($_SERVER['HTTP_SEC_FETCH_SITE']??'same-origin',['same-origin','none'],true)))throw new Fault(403,'Please submit from the configured website.');
 if($method==='GET'&&$origin!==''&&!hash_equals($c['ORIGIN'],$origin))throw new Fault(403,'Request not accepted.');
 ini_set('session.use_strict_mode','1');ini_set('session.use_only_cookies','1');session_name('ih_contact');session_set_cookie_params(['lifetime'=>0,'path'=>'/api/contact.php','secure'=>str_starts_with($c['ORIGIN'],'https://'),'httponly'=>true,'samesite'=>'Strict']);if(!session_start())throw new Fault(503,'Submission service is unavailable.');
 if(!isset($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));
 if($method==='GET'){if(($_GET['action']??'')!=='status')throw new Fault(400,'Invalid request.');contactRespond(200,['enabled'=>true,'csrf'=>$_SESSION['csrf'],'siteKey'=>$c['RECAPTCHA_SITE_KEY'],'captchaVersion'=>$c['RECAPTCHA_VERSION']]);}
 if(($_SERVER['HTTP_X_IHOLYTECH_REQUEST']??'')!=='contact-enquiry'||strtolower(trim(explode(';',$_SERVER['CONTENT_TYPE']??'')[0]))!=='application/json')throw new Fault(415,'Use the enquiry form to submit.');
 if((int)($_SERVER['CONTENT_LENGTH']??0)>20000)throw new Fault(413,'This enquiry is too large.');$raw=file_get_contents('php://input',false,null,0,20001);if($raw===false||strlen($raw)>20000)throw new Fault(413,'This enquiry is too large.');
 try{$d=json_decode($raw,true,16,JSON_THROW_ON_ERROR);}catch(Throwable $e){throw new Fault(400,'Invalid enquiry format.');}
 if(!is_array($d)||array_diff(array_keys($d),['answers','confirmed','honeypot','csrf','captcha','requestId']))throw new Fault(400,'Invalid enquiry format.');
 IHolyTech\Contact\guard($d,$_SESSION['csrf']);
 if(!is_string($d['requestId']??null)||!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',$d['requestId']))throw new Fault(422,'Reload the form before submitting.');
 $answers=IHolyTech\Contact\validate($d['answers']??null);$fingerprint=hash('sha256',json_encode($answers));$id=$d['requestId'];$receipt='Your enquiry and both notification emails are securely queued. Email delivery and response time are not yet confirmed.';
 if(isset($_SESSION['sent'][$id])){if(!hash_equals($_SESSION['sent'][$id],$fingerprint))throw new Fault(409,'This submission reference was already used.');contactRespond(200,['ok'=>true,'message'=>$receipt]);}
 IHolyTech\Contact\rateLimit($c,$_SERVER['REMOTE_ADDR']??'unknown');
 if(!is_string($d['captcha']??null))throw new Fault(422,'Complete security verification.');IHolyTech\Contact\verifyCaptcha($d['captcha'],$c);
 IHolyTech\Contact\deliver($answers,$c,$id);$_SESSION['sent'][$id]=$fingerprint;if(count($_SESSION['sent'])>20)array_shift($_SESSION['sent']);contactRespond(200,['ok'=>true,'message'=>$receipt]);
}catch(Fault $e){if($e->status===429)header('Retry-After: 3600');contactRespond($e->status,['ok'=>false,'message'=>$e->getMessage()]);}catch(Throwable $e){contactRespond(503,['ok'=>false,'message'=>'The enquiry service is unavailable. Nothing has been confirmed as sent.']);}
