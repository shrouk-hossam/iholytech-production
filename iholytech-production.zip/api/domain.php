<?php
declare(strict_types=1);
ini_set('display_errors','0');
define('IH_DOMAIN_BOOTSTRAPPED',true);
// Production runtime is deliberately outside the public document root.
$ihRuntime=getenv('IH_RUNTIME_DIR')?:dirname(__DIR__).'/../iholytech-private-runtime';
$ihRuntime=realpath($ihRuntime);$ihPublic=realpath($_SERVER['DOCUMENT_ROOT']??dirname(__DIR__));
if(!$ihRuntime||!$ihPublic||str_starts_with(strtolower(str_replace('\\','/',$ihRuntime)).'/',strtolower(str_replace('\\','/',$ihPublic)).'/')||!is_file($ihRuntime.'/server/DomainService.php')){http_response_code(503);header('Content-Type: application/json');header('Cache-Control: no-store, private');echo json_encode(['ok'=>false,'message'=>'Service configuration is unavailable.']);exit;}
if(getenv('IH_APP_ENV')===false)putenv('IH_APP_ENV=production');
require $ihRuntime.'/server/DomainService.php';
use IHolyTech\Domain\{Config,Fault,Service,GoDaddyTransport,Limiter};
header_remove('X-Powered-By');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('Content-Security-Policy: default-src \'none\'; frame-ancestors \'none\'');
header('Cross-Origin-Resource-Policy: same-origin');
header('Vary: Origin');
$id=bin2hex(random_bytes(8));
function respond4(int $status,array $data): never {http_response_code($status);echo json_encode($data,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES);exit;}
try {
    $method=$_SERVER['REQUEST_METHOD']??'';
    if(!in_array($method,['GET','POST'],true)){header('Allow: GET, POST');throw new Fault('METHOD_NOT_ALLOWED',405);}
    $root=$_SERVER['DOCUMENT_ROOT']??dirname(__DIR__);if($root==='')$root=dirname(__DIR__);
    try{$config=Config::load($root);}catch(Fault $e){if($method==='GET'&&($_GET['action']??'')==='status'){respond4(200,['enabled'=>false,'message'=>'Live domain search is not enabled yet. No results or prices are shown.']);}throw $e;}
    if($method==='GET'){
        if(($_GET['action']??'')!=='status')throw new Fault('INVALID_REQUEST',400);
        respond4(200,['enabled'=>$config->enabled,'message'=>$config->enabled?'Enter a domain to check availability and view prices.':'Live domain search is not enabled yet. No results or prices are shown.']);
    }
    if(($_SERVER['HTTP_X_IHOLYTECH_REQUEST']??'')!=='domain-search')throw new Fault('FORBIDDEN',403);
    if(strtolower(trim(explode(';',$_SERVER['CONTENT_TYPE']??'')[0]))!=='application/json')throw new Fault('INVALID_CONTENT_TYPE',415);
    if((int)($_SERVER['CONTENT_LENGTH']??0)>2048)throw new Fault('REQUEST_TOO_LARGE',413);
    $raw=file_get_contents('php://input',false,null,0,2049);if($raw===false||strlen($raw)>2048)throw new Fault('REQUEST_TOO_LARGE',413);
    try{$body=json_decode($raw,true,8,JSON_THROW_ON_ERROR);}catch(\Throwable $e){throw new Fault('INVALID_REQUEST',400);}
    if(!is_array($body)||!in_array(array_keys($body),[['domain'],['query']],true))throw new Fault('INVALID_REQUEST',400);
    $input=$body['query']??$body['domain'];
    $domain=$config->pricingMode==='godaddy-api-zero'?$input:IHolyTech\Domain\domainName($input);
    if(!$config->enabled)throw new Fault('SEARCH_DISABLED');
    IHolyTech\Domain\assertOrigin($config->origins,$_SERVER['HTTP_ORIGIN']??'',$_SERVER['HTTP_SEC_FETCH_SITE']??'');
    $service=new Service($config,new GoDaddyTransport($config->pat),new Limiter($config->rateDir,$config->rateSecret));
    $result=$config->pricingMode==='godaddy-api-zero'?(new IHolyTech\Domain\Search($config,new GoDaddyTransport($config->pat),new Limiter($config->rateDir,$config->rateSecret)))->search($domain,$_SERVER['REMOTE_ADDR']??'unknown'):$service->search($domain,$_SERVER['REMOTE_ADDR']??'unknown');
    respond4(200,['ok'=>true,'data'=>$result]);
} catch(Fault $e) {
    if($e->retry>0)header('Retry-After: '.$e->retry);
    $messages=[
        'INVALID_DOMAIN'=>'Enter a domain, a name without an extension, or a short keyword phrase.',
        'IDN_UNSUPPORTED'=>'This domain name cannot be checked by this service yet.',
        'SELLING_PRICE_NOT_APPROVED'=>'Pricing for this domain is not confirmed. No search result has been returned.',
        'DOMAIN_UNCHECKABLE'=>'This domain or extension cannot currently be checked through the connected service.',
        'RATE_LIMITED'=>'Too many searches. Please wait before trying again.',
        'PROVIDER_RATE_LIMITED'=>'The domain service is busy. Please wait before trying again.',
        'SEARCH_DISABLED'=>'Live domain search is not enabled yet. No results or prices are shown.',
        'INVALID_REQUEST'=>'The search request is invalid.',
        'INVALID_CONTENT_TYPE'=>'The search request format is invalid.',
        'REQUEST_TOO_LARGE'=>'The search request is too large.',
        'FORBIDDEN'=>'The search request was not accepted.',
        'METHOD_NOT_ALLOWED'=>'This request method is not supported.'
    ];
    // Log only a local code and correlation ID, never tokens, domains, IPs or upstream bodies.
    if($e->status>=500)error_log('iHolyTech domain service '.$e->kind.' request='.$id);
    respond4($e->status,['ok'=>false,'error'=>['code'=>$e->kind,'message'=>$messages[$e->kind]??'Domain search is temporarily unavailable. No availability result or price has been returned.','retryAfter'=>$e->retry,'requestId'=>$id]]);
} catch(\Throwable $e) {
    error_log('iHolyTech domain service INTERNAL_ERROR request='.$id);
    respond4(503,['ok'=>false,'error'=>['code'=>'SERVICE_UNAVAILABLE','message'=>'Domain search is temporarily unavailable. No results or prices have been returned.','requestId'=>$id]]);
}
